﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TeleBot.Trading
{
    public abstract class MarketBase
    {
        /// <summary>
        /// Money in BTC
        /// </summary>
        public double AvailableMoney { get; set; }

        public abstract double GetCurrentPrice(string currency);

        public abstract void PlaceOrder(double price, double amount, double stopLoss);

        public abstract void PlaceOrder(double price, double amounts);

        public abstract bool IsSupported(string coin);

        public virtual void Initialize()
        {

        }
    }

    public class Agent
    {
        private Task _task;
        private readonly BlockingCollection<TradeSignal> _newSignals = new BlockingCollection<TradeSignal>(100);
        private readonly List<TradeSignal> _waiting = new List<TradeSignal>();
        private const double MaxRisk = 1.0 / 2.0;
        private readonly MarketBase _market;

        public Agent(MarketBase market)
        {
            if (market == null)
            {
                throw new ArgumentNullException("market");
            }
            _market = market;
        }

        public void Start()
        {
            _task = Task.Run(() =>
            {
                Initialize();
                ExecutionLoop();
            });
        }

        private void Initialize()
        {
            _market.Initialize();
        }

        public void Enqueue(TradeSignal signal)
        {
            if (signal == null)
            {
                throw new ArgumentNullException("signal");
            }

            if (!_market.IsSupported(signal.Currency))
            {
                throw new InvalidOperationException($"Currency {signal.Currency} is not supported.");
            }

            _newSignals.Add(signal);
        }

        private void ExecutionLoop()
        {
            while (!_newSignals.IsCompleted)
            {
                try
                {
                    var signal = _newSignals.Take();
                    if (!ProcessAction(signal))
                    {
                        _waiting.Add(signal);
                    }
                }
                catch (InvalidOperationException)
                {

                }
            }
        }

        private bool ProcessAction(TradeSignal signal)
        {
            if (signal == null)
            {
                throw new ArgumentNullException("signal");
            }

            var analysis = Analyzer.Analyze(signal);
            var currentPrice = _market.GetCurrentPrice(signal.Currency);
            // 1. currentPrice < MinBuyPrice
            // 2. currentPrice = [MinBuyPrice, MaxBuyPrice]
            // 3. currentPrice > MaxBuyPrice
            // RiskReward at least 1:2

            var moneyAtRisk = _market.AvailableMoney * 0.05;
            var coins = Math.Floor(moneyAtRisk / currentPrice);
            if (!analysis.HasRisk)
            {
                if (currentPrice >= signal.BuyPriceMin && currentPrice <= signal.BuyPriceMax)
                {
                    _market.PlaceOrder(currentPrice, coins);
                }
            }
            else if (analysis.RiskReward <= MaxRisk)
            {
                if (currentPrice >= signal.BuyPriceMin && currentPrice <= signal.BuyPriceMax)
                {
                    _market.PlaceOrder(currentPrice, coins, signal.StopLoss);
                }
            }
            return true;
        }
    }
}
