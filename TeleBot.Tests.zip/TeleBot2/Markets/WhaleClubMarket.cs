﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeleBot.Trading;

namespace TeleBot.Markets
{
    public class WhaleClubMarket : MarketBase
    {
        public override double GetCurrentPrice(string currency)
        {
            throw new NotImplementedException();
        }

        public override bool IsSupported(string coin)
        {
            throw new NotImplementedException();
        }

        public override void PlaceOrder(double price, double amount, double stopLoss)
        {
            throw new NotImplementedException();
        }

        public override void PlaceOrder(double price, double amounts)
        {
            throw new NotImplementedException();
        }
    }
}
